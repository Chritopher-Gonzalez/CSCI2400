/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_448()
{
    return 4139995209U;
}

void setval_253(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_373()
{
    return 1489171923U;
}

void setval_233(unsigned *p)
{
    *p = 3347663495U;
}

void setval_212(unsigned *p)
{
    *p = 2462290008U;
}

unsigned getval_424()
{
    return 3284633928U;
}

void setval_417(unsigned *p)
{
    *p = 2428995912U;
}

void setval_479(unsigned *p)
{
    *p = 1635764056U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_467(unsigned x)
{
    return x + 3526935177U;
}

void setval_191(unsigned *p)
{
    *p = 3372798345U;
}

unsigned addval_101(unsigned x)
{
    return x + 3286272328U;
}

void setval_324(unsigned *p)
{
    *p = 3674784397U;
}

void setval_118(unsigned *p)
{
    *p = 3223899785U;
}

unsigned addval_344(unsigned x)
{
    return x + 3372797593U;
}

unsigned getval_119()
{
    return 2447411528U;
}

void setval_422(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_396()
{
    return 3523793288U;
}

unsigned getval_181()
{
    return 3352201558U;
}

void setval_430(unsigned *p)
{
    *p = 2425406089U;
}

unsigned getval_131()
{
    return 3374367241U;
}

unsigned getval_127()
{
    return 3532968329U;
}

unsigned getval_488()
{
    return 3531915945U;
}

void setval_397(unsigned *p)
{
    *p = 2447411528U;
}

void setval_352(unsigned *p)
{
    *p = 3767094477U;
}

unsigned getval_130()
{
    return 3523792520U;
}

void setval_483(unsigned *p)
{
    *p = 1002951049U;
}

void setval_198(unsigned *p)
{
    *p = 3767355453U;
}

unsigned addval_355(unsigned x)
{
    return x + 3285289226U;
}

unsigned addval_366(unsigned x)
{
    return x + 3281043977U;
}

unsigned getval_470()
{
    return 3526413961U;
}

unsigned addval_239(unsigned x)
{
    return x + 2495777189U;
}

void setval_433(unsigned *p)
{
    *p = 3682910873U;
}

unsigned getval_102()
{
    return 3225997705U;
}

void setval_128(unsigned *p)
{
    *p = 2464188744U;
}

void setval_480(unsigned *p)
{
    *p = 3677408905U;
}

unsigned addval_494(unsigned x)
{
    return x + 3531919745U;
}

unsigned getval_367()
{
    return 3767093308U;
}

void setval_476(unsigned *p)
{
    *p = 3281048009U;
}

unsigned getval_159()
{
    return 3375943305U;
}

unsigned getval_115()
{
    return 3269495112U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
